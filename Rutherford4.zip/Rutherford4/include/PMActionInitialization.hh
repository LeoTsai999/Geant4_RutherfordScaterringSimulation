// PMActionInitialozation.hh
#ifndef PMACTIONINITIALIZATION_HH
#define PMACTIONINITIALIZATION_HH

#include "G4VUserActionInitialization.hh" // ActionInitialozation.hh 檔案必須引入此檔案
#include "PMPrimaryGenerator.hh"

class PMActionInitialization : public G4VUserActionInitialization
{
public:
    PMActionInitialization(); // CONSTRUCTOR
    ~PMActionInitialization();

    virtual void BuildForMaster() const;
    virtual void Build() const;
};
#endif