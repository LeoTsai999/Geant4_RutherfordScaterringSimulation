// PMPhysicsList.hh
// 以下兩行和最後的 #endif 在 C++ 中為一常見手法，用於確保標頭檔不會被重複編譯
#ifndef PMPHYSICSLIST_HH
#define PMPHYSICSLIST_HH
// 引入必備的Geant4標準庫
#include "G4VModularPhysicsList.hh" // PhysicsList.hh 檔案必須引入此檔案
// 引入想要使用的物理庫
#include "G4EmStandardPhysics.hh"  // 標準的電磁交互作用庫
// 通過繼承 G4VModularPhysicsList，PMPhysicsList 可以註冊各種物理過程
// （例如來自 G4EmStandardPhysics 的電磁過程）並進行配置。
class PMPhysicsList : public G4VModularPhysicsList
{
public:
    PMPhysicsList();   // 聲明建構函數，定義則在.cc檔案中
    ~PMPhysicsList();  // 聲明解構函數，定義則在.cc檔案中
};
#endif
