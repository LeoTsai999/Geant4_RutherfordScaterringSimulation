// PMPrimaryGenerator.hh
#ifndef PMPRIMARYGENERATOR_HH
#define PMPRIMARYGENERATOR_HH

#include "G4VUserPrimaryGeneratorAction.hh" // PrimaryGeneratorAction.hh 檔案必須引入此檔案
// 粒子種類、粒子槍、單位 之管理
#include "G4ParticleDefinition.hh"
#include "G4ParticleGun.hh"
#include "G4ParticleTable.hh"
#include "G4SystemOfUnits.hh"

class PMPrimaryGenerator : public G4VUserPrimaryGeneratorAction
{
public:
    PMPrimaryGenerator();      // 聲明建構函數
    ~PMPrimaryGenerator();     // 聲明解構函數

    virtual void GeneratePrimaries(G4Event *);

private:
    G4ParticleGun *fParticleGun;
};

#endif