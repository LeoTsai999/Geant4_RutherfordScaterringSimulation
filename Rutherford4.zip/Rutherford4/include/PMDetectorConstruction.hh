//  PMDetectorConstruction.hh
#ifndef PMDETECTORCONSTRUCTION_HH
#define PMDETECTORCONSTRUCTION_HH

#include "G4VUserDetectorConstruction.hh" // DetectorConstruction.hh 檔案必須引入此檔案
// IN2P3將欲使用幾何體於.cc檔案引入。此版本統一在.hh檔案中進行聲明
#include "G4Box.hh"
#include "G4Tubs.hh"
// 邏輯空間、物理空間、放置
#include "G4LogicalVolume.hh"
#include "G4VPhysicalVolume.hh"
#include "G4PVPlacement.hh"
// 材料與單位管理
#include "G4Material.hh"
#include "G4NistManager.hh"
#include "G4SystemOfUnits.hh"
#include "G4UnitsTable.hh"
// 可視化相關
#include "G4VisAttributes.hh"
#include "G4Color.hh"
#include "G4SDManager.hh"
// 敏感探測器
#include "PMSensitiveDetector.hh"

// C++標準庫
#include <cmath>

class PMDetectorConstruction : public G4VUserDetectorConstruction // 定義了一個名為 PMDetectorConstruction 的類，
{                                                                 // 該類繼承自 G4VUserDetectorConstruction(Geant4 模擬工具包中的一個基類)
    public:
        PMDetectorConstruction();                   // 建構函數
        virtual ~PMDetectorConstruction() ;         // 虛擬解構函數

        virtual G4VPhysicalVolume *Construct();
    private:
        G4LogicalVolume *logicZnS_screen;           // 在這裡聲明敏感探測器的邏輯體!!!!!!!!!!!

        virtual void ConstructSDandField();
};

#endif