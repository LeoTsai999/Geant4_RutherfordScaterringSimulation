#ifndef PMSENSITIVEDETECTOR_HH
#define PMSENSITIVEDETECTOR_HH

#include "G4VSensitiveDetector.hh"
#include "G4SystemOfUnits.hh"
#include "G4UnitsTable.hh"
#include <cmath>
#include <vector>
#include <fstream>

struct HitData {
    G4double angle; // 角度（單位：度）
    G4double energyDeposited; // 能量沉積（單位：MeV）
    G4int eventID; // 事件 ID
};

class PMSensitiveDetector : public G4VSensitiveDetector
{
public:
    PMSensitiveDetector(G4String);
    ~PMSensitiveDetector();

private:
    G4double fTotalEnergyDeposited;
    G4double fDistanceBetweenParticleAndGun;
    std::vector<HitData> fHitCollection; // 儲存所有擊中資料
    std::ofstream fOutputFile; // 檔案流

    virtual void Initialize(G4HCofThisEvent *) override;
    virtual void EndOfEvent(G4HCofThisEvent *) override;
    virtual G4bool ProcessHits(G4Step *, G4TouchableHistory *);

public:
    void WriteToFile(); // 寫入檔案的方法
};

#endif