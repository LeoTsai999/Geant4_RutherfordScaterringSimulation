// PMPrimaryGenerator.cc
#include "PMPrimaryGenerator.hh"

PMPrimaryGenerator::PMPrimaryGenerator()   // 定義建構函數
{
    fParticleGun = new G4ParticleGun(1000); // 50 表示一個event打50個particle

    // 定義粒子槍位置
    G4double x = 0. *cm;
    G4double y = 0. *cm;
    G4double z = -25. *cm;
    G4ThreeVector pos(x,y,z); // 由前三行宣告的x y z建立位置向量pos(x,y,z)

    // 定義粒子槍方向 注意在Geant4中說的動量，只考慮方向而已
    G4double px = 0.;
    G4double py = 0.;
    G4double pz = 1.;
    G4ThreeVector mom(px,py,pz); // 由前三行宣告的px py pz建立動量向量mom(x,y,z)

    // 定義粒子種類
    G4ParticleTable *particleTable = G4ParticleTable::GetParticleTable();
    G4ParticleDefinition *particle = particleTable->FindParticle("alpha");

    // 定義粒子能量
    G4double ene = 1 *MeV;

    // 現在已經準備好粒子槍的所有材料了，開始定義粒子槍： (這四行都不用動，要改參數去前面改)
    fParticleGun->SetParticlePosition(pos); // 前面在準備的時候已經宣告好變數pos
    fParticleGun->SetParticleMomentumDirection(mom); // 前面在準備的時候已經宣告好變數mom
    fParticleGun->SetParticleEnergy(ene);
    fParticleGun->SetParticleDefinition(particle); // 前面在準備的時候已經宣告好變數particle
}


PMPrimaryGenerator::~PMPrimaryGenerator()  // 定義解構函數
{
    delete fParticleGun;
}

void PMPrimaryGenerator::GeneratePrimaries(G4Event *anEvent)
{
    // 創造一個vertex(粒子軌跡或事件的起點)
    fParticleGun->GeneratePrimaryVertex(anEvent); //射一次
}

