#include "PMSensitiveDetector.hh"
#include "G4RunManager.hh"

PMSensitiveDetector::PMSensitiveDetector(G4String name) : G4VSensitiveDetector(name)
{
    fTotalEnergyDeposited = 0.;
    // 在建構函數中打開輸出檔案
    fOutputFile.open("particle_data.txt", std::ofstream::out);
    if (!fOutputFile.is_open()) {
        G4cerr << "錯誤：無法打開 particle_data.txt 進行寫入！" << G4endl;
    }
    else {
        G4cout << "成功打開 particle_data.txt 進行寫入。" << G4endl;
        // 寫入標頭
        fOutputFile << "事件ID\t角度(度)\n";
        fOutputFile.flush();
    }
}

PMSensitiveDetector::~PMSensitiveDetector()
{
    G4cout << "PMSensitiveDetector 解構函數調用，寫入檔案..." << G4endl;
    WriteToFile();
    if (fOutputFile.is_open()) {
        fOutputFile.close();
        G4cout << "輸出檔案已關閉。" << G4endl;
    }
}

void PMSensitiveDetector::Initialize(G4HCofThisEvent *)
{
    fTotalEnergyDeposited = 0.; // 重置事件能量
    fHitCollection.clear(); // 清空當前事件的擊中數據
    G4cout << "PMSensitiveDetector 初始化，事件開始。" << G4endl;
}

void PMSensitiveDetector::EndOfEvent(G4HCofThisEvent *)
{
    G4cout << "事件結束，能量沉積: " << fTotalEnergyDeposited << " MeV, 擊中數: " << fHitCollection.size() << G4endl;
    WriteToFile(); // 在每個事件結束時寫入數據
}

G4bool PMSensitiveDetector::ProcessHits(G4Step* aStep, G4TouchableHistory *)
{
    // 獲取此步的能量沉積（仍計算，但不用於條件）
    G4double fEnergyDeposited = aStep->GetTotalEnergyDeposit() / MeV;

    // 獲取粒子動量方向
    G4ThreeVector dir = aStep->GetPreStepPoint()->GetMomentumDirection();

    // 計算角度（單位：度）
    G4double angle = std::atan2(dir.x(), dir.z()) * 180.0 / M_PI;

    // 獲取事件 ID
    G4int eventID = G4RunManager::GetRunManager()->GetCurrentEvent()->GetEventID();

    // 儲存擊中資料（無條件記錄）
    fTotalEnergyDeposited += fEnergyDeposited;
    HitData hit;
    hit.angle = angle;
    hit.energyDeposited = fEnergyDeposited; // 保留此欄位以符合 HitData 結構
    hit.eventID = eventID;
    fHitCollection.push_back(hit);

    G4cout << "記錄擊中：事件ID=" << eventID << ", 角度=" << angle << " 度, 能量沉積=" << fEnergyDeposited << " MeV" << G4endl;

    return true;
}

void PMSensitiveDetector::WriteToFile()
{
    if (!fOutputFile.is_open()) {
        G4cerr << "錯誤：輸出檔案未打開！" << G4endl;
        return;
    }

    // 寫入所有擊中資料（僅輸出事件ID和角度）
    G4cout << "寫入 " << fHitCollection.size() << " 個擊中數據到檔案。" << G4endl;
    for (const auto& hit : fHitCollection) {
        fOutputFile << hit.eventID << "\t"
                    << hit.angle << "\n";
    }
    fOutputFile.flush(); // 確保數據寫入磁碟
    fHitCollection.clear(); // 清空已寫入的數據，防止重複寫入
}