// PMDetectorConstruction.cc
#include "PMDetectorConstruction.hh"

PMDetectorConstruction::PMDetectorConstruction() // 定義建構函數PMDetectorConstruction(), 它屬於PMDetectorConstruction類
{
	G4cout << "===== PMDetectorConstruction::PMDetectorConstruction 建構函數被調用" << G4endl;
}

PMDetectorConstruction::~PMDetectorConstruction() // 定義解構函數~PMDetectorConstruction(), 它屬於PMDetectorConstruction類
{
	G4cout << "===== PMDetectorConstruction::~PMDetectorConstruction 解構函數被調用" << G4endl;
}

G4VPhysicalVolume *PMDetectorConstruction::Construct() // Construct 函數負責構建 Geant4 模擬的物理世界 -> 在這裡面編輯你的世界。
{                                                      // Construct 是 PMDetectorConstruction 類的成員函數。
                                                       // Construct 函數返回一個 G4VPhysicalVolume* 指標，也就是 physWorld
	// 定義圓周率常數
	const G4double pi = M_PI;
    G4bool checkOverlaps = true;

    // 利用nistmanager定義材料
	G4NistManager *nist = G4NistManager::Instance(); // 創建nistmanager。必須使用這一行代碼才能在後續程式中使用nist manager。
	G4Material *goldMat = nist->FindOrBuildMaterial("G4_Au");
	G4Material *vacuumMat = nist->FindOrBuildMaterial("G4_Galactic");

	// 自定義材料: 硫化鋅ZnS
	G4Element* Zn = nist->FindOrBuildElement("Zn");
	G4Element* S = nist->FindOrBuildElement("S");
	G4Material* ZnSMat = new G4Material("ZincSulfide", 4.09 * g/cm3, 2);
	ZnSMat->AddElement(Zn, 1);
	ZnSMat->AddElement(S, 1);


	// 定義世界
    G4double xWorld = 1. *m;
    G4double yWorld = 1. *m;
    G4double zWorld = 1. *m;
    G4Box *solidWorld = new G4Box("solidWorld",
                                   0.5 * xWorld,
                                   0.5 * yWorld,
                                   0.5 * zWorld);
    G4LogicalVolume *logicWorld = new G4LogicalVolume(solidWorld,
                                                      vacuumMat,
                                                      "logicalWorld");
    G4VPhysicalVolume *physWorld = new G4PVPlacement(0,
                                                     G4ThreeVector(0., 0., 0.),
                                                     logicWorld,
                                                     "physWorld",
                                                     0,            // World就是最大的，所以沒有母體空間
                                                     false,
                                                     0,
                                                     checkOverlaps);
    // 定義金箔
    G4double goldThickness = 0.00002 *mm;
    G4double goldSize = 10. *cm;
    G4Box *solidGold = new G4Box("solidGold", 0.5 * goldSize,
                                              0.5 * goldSize,
                                              0.5 * goldThickness);
    G4LogicalVolume *logicGold = new G4LogicalVolume(solidGold,
                                                       goldMat,
                                                       "logicgold");
    G4VPhysicalVolume *physGold = new G4PVPlacement(0,
                                                   G4ThreeVector(0.*cm, 0.*cm, 0. *cm),
                                                   logicGold,
                                                   "physGold",
                                                   logicWorld, // 告訴程式這物件的母空間是logicWorld
                                                   false,
                                                   checkOverlaps);
	// 金箔的visulize
	G4VisAttributes *goldVisAtt = new G4VisAttributes(G4Color(1.0, 0.843, 0.0, 0.5)); // 改顏色：r g b alpha
	goldVisAtt->SetForceSolid (true); // 指定為solid物件
	logicGold->SetVisAttributes (goldVisAtt); // 屬性要放入邏輯空間

	// 定義硫化鋅屏幕
	G4double InRadius = 50.0 *cm;
	G4double OutRadius = 51.0 *cm;
	G4double Height = 30.0 *cm;
	G4double StartAngle = 0;               // 注意單位是弧度
	G4double SegementAngle = 2 * M_PI;	   // 注意單位是弧度

	// 定義繞 x 軸旋轉 90 度的旋轉矩陣
	G4RotationMatrix* xrotation = new G4RotationMatrix();
	xrotation->rotateX(90. * deg); // 繞 x 軸旋轉 90 度

	G4Tubs *ZnS_screen = new G4Tubs("ZnS_screen",                                         // 建立實體 ZnS_screen
                                  InRadius,
                                  OutRadius,
                                  0.5 * Height,
                                  StartAngle,
                                  SegementAngle);
	logicZnS_screen = new G4LogicalVolume(ZnS_screen,                                    // 把實體 ZnS_screen 塞到邏輯體 logicZnS_screen 中        記得要去PMDetectorConstruction中聲明!!!!!!!!!
	                                    ZnSMat,                                          // 材料為硫化鋅(ZnsMat)
	                                    "logicZnS_screen");
	G4VPhysicalVolume *physZnS_screen = new G4PVPlacement(xrotation,
	                                                      G4ThreeVector(0.*cm, 0.*cm, 0. *cm),  // 把邏輯體 logicZnS_screen 塞到物理體 physZnS_screen 中
	                                                      logicZnS_screen,
	                                                      "physZnS_screen",
	                                                      logicWorld,          // 告訴程式這物件的母空間是logicWorld
	                                                      false,
	                                                      checkOverlaps);
	// 硫化鋅屏幕的visulize
	G4VisAttributes *ZnS_screenVisAtt = new G4VisAttributes(G4Color(0.502, 0.502, 0.502, 0.5));  // 改顏色：r g b alpha
	ZnS_screenVisAtt->SetForceSolid (true);
	logicZnS_screen->SetVisAttributes(ZnS_screenVisAtt);


	return physWorld;
}

void PMDetectorConstruction::ConstructSDandField()
{

	G4SDManager::GetSDMpointer()->SetVerboseLevel(0);

	PMSensitiveDetector *sensDet = new PMSensitiveDetector("SensitiveDetector"); // 建立敏感探測器 sensDet
	logicZnS_screen->SetSensitiveDetector(sensDet);                              // 將敏感探測器 sensDet關聯到邏輯體 logicZnS_screen。
                                                                                 // 當粒子與此邏輯體交互時，Geant4 會調用 PMSensitiveDetector 的方法來處理交互數據（例如記錄命中信息）。
	G4SDManager::GetSDMpointer()->AddNewDetector(sensDet);                       // 將敏感探測器註冊到 SD 管理器
}