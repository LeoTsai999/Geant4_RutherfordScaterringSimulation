// PMPhysicsList.cc
#include "PMPhysicsList.hh"

PMPhysicsList::PMPhysicsList()  // 定義建構函數
{
	// 電磁交互物理 .hh檔案中已聲明 include "G4EmStandardPhysics.hh"
	RegisterPhysics(new G4EmStandardPhysics());
}

PMPhysicsList::~PMPhysicsList() // 定義解構函數
{
}
